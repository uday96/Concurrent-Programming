#include<iostream>
#include<vector>
#include<string>
#include<stdlib.h>
#include<fstream>
using namespace std;
class TreeNode
{
	public:
		int id;
		TreeNode* left;
		TreeNode* right;
		int wt;
		TreeNode(int N)
		{
			id = N;
			wt = rand()%10;
			left = NULL;
			right = NULL;
		}

};
TreeNode* root;
int distribution;
vector<TreeNode*> V;
void BTGen(TreeNode*&root, int N)
{
	if(root ==NULL){
		root = new TreeNode(N);
		V.push_back(root);
		return;
	}

	int p = rand()%100;
	if(p < distribution)
		BTGen(root->left, N);
	else
		BTGen(root->right, N);


}

int configSkew(string type)
{
	if(type == "lst")
		return 101;
	if(type == "rst")
		return 0;
	if(type == "rbt")
		return (rand()%100 + 5)%100;
	if(type == "bbt")
		return 50;
	if(type == "cbt")
		return 150;
	return (rand()%100 + 5)%100;

}
int main(int argc, char* argv[])
{
	srand(time(NULL));
	if(argc != 4){
		cout<<"Not enough arguments\n";
		return 0;
	}
	int N = atoi(argv[1]);
//	string skew = argv[2];
	
	distribution = configSkew(argv[2]);
	if(distribution != 150)	
		for(int i = 1;i<=N;i++)
			BTGen(root, i);
	
	ofstream fp(argv[3]);
	//output to file
	fp<<N<<endl;
	for(int i=0;i<N; i++)
	{
		if(distribution !=150)
		{
			int l =	V[i]->left!=NULL?(V[i]->left)->id:0;
			int r = V[i]->right!=NULL?(V[i]->right)->id:0;
			fp<<V[i]->id<<" "<<V[i]->wt<<" "<<l<<" "<<r<<endl;
		}
		else
		{	int id = i+1;
			int l = (id * 2)<=N?(id*2):0;
			int r = ((id * 2) + 1 <= N)? ((id*2)+1):0;
			fp<<id<<" "<<rand()%10<<" "<<l<<" "<<r<<endl;
		
		}

	}
}
