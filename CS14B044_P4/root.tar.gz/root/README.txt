Usage guidelines.

1. Copy your submission directory having name as your roll number into "./submissions/".

2. Make sure your directory name is in capital letters.

3. You can delete an existing directory "./submissions/CS14D211", as it is just for your reference as an example.

4. run "./eval.sh" 
	-For serial execution of your code, pass "-serial" an an argument to script. By default it is parallel.
	- For example, 
		./eval.sh -serial

	- No need to give other parameters, script will take care of it.

5. At the end, you should able to see your score, if you could, your submission follows the expected format, else make appropriate changes.

6. Compress your submission (which you earlier copied into ./submissions/) into ".tar.gz" and submit on moodle.

