#!/bin/bash
CONFIG="1 2 4 8"
MAXITER=3
MODE=$1
if [ "$MODE" == "" ]
then
	MODE="-parallel"
fi

ROOT=$(pwd)
DIR=$(ls submissions | grep "^[A-Z][A-Z][1-9][1-9][A-Z][0-9][1-9][1-9]$")
if [ "$DIR" == "" ]
then
	echo "Follow the guidelines. Could not find a directory with your roll number in CAPS."
	exit
fi

#for i in ./*; 
#do
#	i=$(echo $i | cut -f2 -d'/')
#	if [ ! -d $i ]
#	then
#		continue
#	fi
#	echo $i;
#	T=$(echo $i | grep "^[A-Z][A-Z][1-9][1-9][A-Z][0-9][1-9][1-9]$")
#	if [ "$T" != "" ] 
#	then
#		DIR=$i
#		break
#	fi
#done
echo "Running evaluation on $DIR"

if [ ! -d "submissions/$DIR/P4" ]
then
	echo "$DIR does not contain P4!"
	exit
fi

### Compilation
cd submissions/$DIR/P4
OUT=$(gcc -std=c99 -fopenmp P4.c kempe.c util.c -o P4 -lm)
if [ "$OUT" != "" ]
then
	echo "Compilation message for $ROLL -- $OUT" 
	exit
fi

### Execution
VERS=$(submissions/gcc --version)
#echo "Evaluating with version: $VERS"
ID=$(date | sed 's/ //g' | sed 's/://g')
RESULTDIR=$ROOT/results/results${ID}
mkdir -p $RESULTDIR
TESTCOUNT=$(ls $ROOT/testcases/input/ | wc -l)
MAXPERTEST=$(echo "scale=4; 100.0/$TESTCOUNT" | bc -l)
MAXCORRECTNESSMARKS=$(echo "scale=4; $MAXPERTEST*0.35" | bc -l)
MAXJUMPMARKS=$(echo "scale=4; $MAXPERTEST*0.11667" | bc -l | awk '{printf "%f", $1}')
echo "Maximum marks per testcase: $MAXPERTEST ($MAXCORRECTNESSMARKS + 3 * $MAXJUMPMARKS + $MAXPERTEST * 0.1)"
ROLL=$DIR
echo "*** Evaluating P4 for $ROLL"
ROLLFILE=$RESULTDIR/${ROLL}.out
cd $ROOT/submissions/$ROLL/P4
TOTALMARKS=0
for TEST in $(ls $ROOT/testcases/input)
#for TEST in P4_14.txt
do
	FLAG=1
	echo -e "** Evaluating $TEST."
	echo -ne "$TEST:" >> $ROLLFILE
	CORRECT=0

	# Obtain the expected output, number of iterations, and colors.

	EXPECTED=$(cat $ROOT/testcases/output/$TEST)
	EXPSIZE=$(echo "$EXPECTED" | wc -l)
	let "EXPEND=EXPSIZE-4"
	EXPECTED=$(echo "$EXPECTED" | sed -n 3,${EXPEND}p)
	T=$(echo $TEST | cut -f1 -d'.')
	COLORS=$(cat $ROOT/testcases/colors.txt | grep $T | cut -f2 -d' ')

	TESTMARKS=0
	if [ "$EXPECTED" == "" ]
	then
		echo "Can not accept empty output file $ROOT/testcases/output/$TEST"
		exit
	fi

	JUMPS=0
	#ALLITER=8
	NC=$(echo $CONFIG | wc -w)
	ALLITER=$(echo "$NC * $MAXITER" | bc -l)
	for NT in $CONFIG
	do
		ITER=1
		AVGTIME=0.0
		THISCORRECT=0
		#MAXITER=2
		while [ $ITER -le $MAXITER ]
		do
			if [ "$FLAG" == "1" ]
			then
				OUT=$(timeout 120 ./P4 $NT $COLORS $MODE < $ROOT/testcases/input/$TEST 2> /dev/null)
			else
				OUT=""
			fi

			THISTIME=$(echo "$OUT" | grep "Total time" | cut -f2 | cut -f1 -d' ')
			if [ "$THISTIME" != "" ]
			then
				echo $THISTIME
				# Obtain the generated output.
				THISSIZE=$(echo "$OUT" | wc -l)
				let "THISEND=THISSIZE-4"
				OUT=$(echo "$OUT" | sed -n 3,${THISEND}p)
			else
				echo "Incorrect/Timeout (120s)."
				OUT=""
			fi

			#Verify the output with expected answer.
			#If the verification succeeds, add 1 to CORRECT.
			if [ "$OUT" == "$EXPECTED" ]
			then
				let "CORRECT=CORRECT+1"
				let "THISCORRECT=THISCORRECT+1"
				AVGTIME=$(echo "scale=7; $AVGTIME + ($THISTIME - $AVGTIME)/$ITER" | bc -l | awk '{printf "%f", $0}')
			else
				FLAG=0
				let "AVGTIME=10000"
				echo -e "The output is incorrect!"
			fi
			let "ITER=ITER+1"
		done

		# If all 5 runs gave correct answer, then find the speedup obtained with previous.
		if [ $THISCORRECT -ne $MAXITER ]
		then
			echo -ne "  10000" >> $ROLLFILE
			echo -e "\t $NT threads: Incorrect."
			let "AVGTIME=10000"
		else 
			echo -ne "  $AVGTIME" >> $ROLLFILE
			echo -e "\t $NT threads: ${AVGTIME}s."
			# Except for the first entry, or previously incorrect entries.
			if [ "$NT" -ne 1 ]
			then
				POSITIVE=$(echo "scale=4; (${OLDTIME}/${AVGTIME}*1.0) >= 1.01" | bc -l)
				VALID=$(echo "scale=4; $OLDTIME != 10000 " | bc -l)
				if [ "$POSITIVE" == 1 -a "$VALID" == 1 ]
				then
					let "JUMPS=JUMPS+1"
				fi
				if [ "$VALID" == 1 ]
				then
					OLDTIME=$AVGTIME
				fi
			fi
		fi
		if [ $NT -eq 1 ]
		then
			OLDTIME=$AVGTIME
		fi
	done
	#If CORRECT is not $ALLITER, then give zero marks for this assignment.
	if [ $CORRECT -ne $ALLITER ]
	then
		TESTMARKS=0
		JUMPS=0
		echo "Testcase failed."
	else
		echo "Testcase passed with $JUMPS positive speedup(s)."
		TESTMARKS=$(echo "scale=4; $TESTMARKS + $MAXCORRECTNESSMARKS + $MAXJUMPMARKS*$JUMPS" | bc -l| awk '{printf "%f", $0}')
	fi
	echo "  $JUMPS" >> $ROLLFILE
	TOTALMARKS=$(echo "scale=4; $TOTALMARKS + $TESTMARKS" | bc -l | awk '{printf "%f", $0}')
done
echo -e "\t Total marks obtained by $ROLL (out of 70): $TOTALMARKS\n"
echo -e "\t Total marks obtained by $ROLL (out of 70): $TOTALMARKS\n" >> $ROLLFILE
