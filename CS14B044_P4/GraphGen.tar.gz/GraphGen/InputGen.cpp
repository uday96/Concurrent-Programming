/* Graph generator
 * Command-line input: Number of vertices
 * Output: Sparse adjecency matrix
 */



#include<iostream>
#include<vector>
#include<stdlib.h>
#include<set>

using namespace std;

int main(int argc, char* argv[])
{
        srand (time(NULL));
        int n = atoi(argv[1]);

        long max_edges = n*(n-1)/2;
        long num_edges = (0.2*max_edges) + rand()%(int)(0.7 * max_edges);

        vector<set<int> >V(n);


        for(int i=0;i<num_edges;i++)
        {
                int u = rand()%n;
                int v = rand()%n;

                V[u].insert(v);
                V[v].insert(u);
        }
        cout<<n<<endl;
        for(int i=0;i<n;i++)
        {
                cout<<V[i].size()<<" ";
                set<int>::iterator it;
                for(it = V[i].begin(); it!=V[i].end();it++)
                        cout<<*it<<" ";

                cout<<endl;
        }

}

